
export interface ScriptSegment {
  time: string;
  segment: string; // Hook, Problem, Solution, etc.
  text: string;
  visual_cue: string;
  imageUrl?: string;
  isGeneratingImage?: boolean;
}

export interface GeneratedContent {
  hooks: string[];
  script: ScriptSegment[];
  ctas: string[];
  caption: string;
  hashtags: string[];
  thumbnail_texts: string[];
  benefits: string[];
  pain_points: string[];
}

export interface UserInput {
  productInfo: string; // Name or URL
  targetAudience: string[];
  useCase: string[];
  productImages: string[]; // Base64 strings
  language: string;
}

export enum LoadingState {
  IDLE = 'IDLE',
  LOADING = 'LOADING',
  SUCCESS = 'SUCCESS',
  ERROR = 'ERROR',
}