
import { GoogleGenAI, Type, Schema } from "@google/genai";
import { GeneratedContent, UserInput } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const scriptSchema: Schema = {
  type: Type.OBJECT,
  properties: {
    hooks: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "3 Short, emotional viral hooks in the requested language.",
    },
    script: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          time: { type: Type.STRING, description: "Time range e.g. 0-3s" },
          segment: { type: Type.STRING, description: "Segment name e.g. Hook, Problem, Solution" },
          text: { type: Type.STRING, description: "Spoken audio script in the requested language." },
          visual_cue: { type: Type.STRING, description: "Visual description for the video editor." },
        },
        required: ["time", "segment", "text", "visual_cue"],
      },
      description: "Video script segments following the timeline: Hook, Problem, Solution, Benefits, CTA.",
    },
    ctas: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Strong Call-to-Actions in the requested language.",
    },
    caption: {
      type: Type.STRING,
      description: "High-CTR SEO optimized caption for Indian audience.",
    },
    hashtags: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Trending hashtags for India #1 ranking style.",
    },
    thumbnail_texts: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "5 Options for thumbnail text in the requested language, 2-4 words each.",
    },
    benefits: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "5 Key product benefits in the requested language.",
    },
    pain_points: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "3 Pain points solved by the product in the requested language.",
    },
  },
  required: ["hooks", "script", "ctas", "caption", "hashtags", "thumbnail_texts", "benefits", "pain_points"],
};

export const generateAffiliateContent = async (input: UserInput): Promise<GeneratedContent> => {
  const languageInstruction = input.language === 'Hinglish' 
    ? 'Hinglish (Hindi + English mix, conversational)' 
    : input.language;

  const promptText = `
    You are an expert India-based Affiliate Video Content Generator Tool.
    Generate high-converting content for YouTube Shorts & Instagram Reels.
    
    Product/Input: ${input.productInfo}
    Target Audience: ${input.targetAudience.join(', ')}
    Use-Case: ${input.useCase.join(', ')}

    Requirements:
    1. Language: ${languageInstruction}. 
       CRITICAL: The Script, Hooks, CTAs, Benefits, Pain Points, and Thumbnail Text MUST be in ${languageInstruction}.
    2. Tone: Energetic, fast-paced, emotional, and relatable to Indian middle-class buyers.
    3. Structure the SCRIPT exactly as follows:
       - Hook (0-3 sec): Shocking or relatable start.
       - Problem (3-6 sec): The pain point.
       - Solution/Product Intro (6-10 sec): The "Jugaad" or fix.
       - Benefits (10-18 sec): Rapid fire features.
       - CTA (18-22 sec): Call to action.
    4. Output valid JSON matching the schema.
    5. Ensure cultural relevance to India (e.g., mentioning festivals, savings/bachat, daily struggles).
  `;

  const parts: any[] = [{ text: promptText }];

  // Attach images if provided to help the model understand the product
  if (input.productImages && input.productImages.length > 0) {
    input.productImages.forEach((base64Img) => {
      parts.push({
        inlineData: {
          mimeType: "image/jpeg", // Assuming JPEG for simplicity, but API handles common formats
          data: base64Img,
        },
      });
    });
  }

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: scriptSchema,
        temperature: 0.85, 
      },
    });

    const text = response.text;
    if (!text) throw new Error("No content generated");
    
    return JSON.parse(text) as GeneratedContent;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const generateImageForSegment = async (visualCue: string, referenceImage?: string, aspectRatio: string = "1:1"): Promise<string | null> => {
  const prompt = `Photorealistic 4k image, ${visualCue}, high quality, professional product photography style, cinematic lighting, realstick`;
  
  const parts: any[] = [{ text: prompt }];

  if (referenceImage) {
    parts.push({
        inlineData: {
            mimeType: "image/jpeg",
            data: referenceImage
        }
    });
    parts.push({ text: "Use the above image as a reference for the product." });
  }

  try {
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-image',
        contents: { parts },
        config: {
            // responseMimeType is not supported for this model
            imageConfig: {
                aspectRatio: aspectRatio
            }
        }
    });

    // Extract image
    for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
            return part.inlineData.data;
        }
    }
    return null;
  } catch (error) {
    console.error("Image Gen Error:", error);
    throw error;
  }
};
