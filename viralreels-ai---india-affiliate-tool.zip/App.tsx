
import React, { useState } from 'react';
import { 
  Sparkles, 
  Zap, 
  Target, 
  ShoppingBag, 
  Youtube, 
  Instagram, 
  Loader2,
  AlertCircle,
  MessageCircle,
  Hash,
  Image as ImageIcon,
  CheckCircle2,
  AlertTriangle,
  LayoutDashboard,
  Upload,
  X,
  ImagePlus,
  LucideIcon,
  Globe
} from 'lucide-react';
import { generateAffiliateContent, generateImageForSegment } from './services/geminiService';
import { GeneratedContent, UserInput, LoadingState } from './types';
import ScriptTimeline from './components/ScriptTimeline';
import ResultSection from './components/ResultSection';

const SUGGESTED_AUDIENCES = [
  "College Students",
  "Home Makers",
  "Tech Geeks",
  "Fitness Freaks",
  "New Parents",
  "Budget Buyers"
];

const SUGGESTED_USE_CASES = [
  "Daily Life Hack",
  "Perfect Gift",
  "Money Saver",
  "Room Decor",
  "Travel Essential",
  "Productivity Boost"
];

const LANGUAGES = [
    { id: 'Hinglish', label: 'Hinglish', sub: 'Mix' },
    { id: 'Hindi', label: 'Hindi', sub: 'हिंदी' },
    { id: 'English', label: 'English', sub: 'Global' },
];

interface MultiSelectInputProps {
    label: string;
    icon: LucideIcon;
    value: string[];
    onChange: (val: string[]) => void;
    suggestions: string[];
    placeholder: string;
    colorTheme: 'indigo' | 'amber';
}

const MultiSelectInput: React.FC<MultiSelectInputProps> = ({ 
    label, 
    icon: Icon, 
    value, 
    onChange, 
    suggestions, 
    placeholder, 
    colorTheme 
}) => {
    const [inputValue, setInputValue] = useState("");

    const handleKeyDown = (e: React.KeyboardEvent) => {
        if (e.key === 'Enter' && inputValue.trim()) {
            e.preventDefault();
            if (!value.includes(inputValue.trim())) {
                onChange([...value, inputValue.trim()]);
            }
            setInputValue("");
        } else if (e.key === 'Backspace' && !inputValue && value.length > 0) {
            onChange(value.slice(0, -1));
        }
    };

    const toggleSuggestion = (item: string) => {
        if (value.includes(item)) {
            onChange(value.filter(v => v !== item));
        } else {
            onChange([...value, item]);
        }
    };

    const removeItem = (item: string) => {
        onChange(value.filter(v => v !== item));
    };

    // Dark theme styles map
    const styles = {
        indigo: {
            icon: "text-indigo-400",
            borderFocus: "focus-within:border-indigo-500/50",
            ringFocus: "focus-within:ring-indigo-500/10",
            tagBg: "bg-indigo-500/20",
            tagText: "text-indigo-300",
            tagBorder: "border-indigo-500/30",
            suggestionActive: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30 shadow-sm shadow-indigo-900/20",
            suggestionHover: "hover:border-indigo-500/50 hover:text-indigo-300"
        },
        amber: {
            icon: "text-amber-400",
            borderFocus: "focus-within:border-amber-500/50",
            ringFocus: "focus-within:ring-amber-500/10",
            tagBg: "bg-amber-500/20",
            tagText: "text-amber-300",
            tagBorder: "border-amber-500/30",
            suggestionActive: "bg-amber-500/20 text-amber-300 border-amber-500/30 shadow-sm shadow-amber-900/20",
            suggestionHover: "hover:border-amber-500/50 hover:text-amber-300"
        }
    };

    const theme = styles[colorTheme];

    return (
        <div>
            <label className="block text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
                <Icon size={18} className={theme.icon} />
                {label}
            </label>
            
            <div className={`w-full px-3 py-3 rounded-2xl bg-slate-950 border border-slate-800 transition-all shadow-sm hover:border-slate-700 flex flex-wrap gap-2 min-h-[60px] ${theme.borderFocus} focus-within:ring-4 ${theme.ringFocus}`}>
                {value.map((item, idx) => (
                    <span key={idx} className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-sm font-semibold border ${theme.tagBg} ${theme.tagText} ${theme.tagBorder} animate-fade-in`}>
                        {item}
                        <button onClick={() => removeItem(item)} className="hover:bg-black/20 rounded-full p-0.5 transition-colors">
                            <X size={12} />
                        </button>
                    </span>
                ))}
                <input
                    type="text"
                    className="flex-grow bg-transparent outline-none text-slate-200 placeholder:text-slate-600 text-base min-w-[120px] py-1 px-1"
                    placeholder={value.length === 0 ? placeholder : ""}
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={handleKeyDown}
                />
            </div>

            <div className="flex flex-wrap gap-2 mt-3">
                {suggestions.map((suggestion) => {
                    const isActive = value.includes(suggestion);
                    return (
                        <button
                            key={suggestion}
                            type="button"
                            onClick={() => toggleSuggestion(suggestion)}
                            className={`text-[11px] font-semibold px-3 py-1.5 rounded-full border transition-all ${
                                isActive 
                                ? theme.suggestionActive 
                                : `bg-slate-900 text-slate-500 border-slate-800 hover:bg-slate-800 ${theme.suggestionHover}`
                            }`}
                        >
                            {suggestion}
                        </button>
                    );
                })}
            </div>
        </div>
    );
};

const App: React.FC = () => {
  const [input, setInput] = useState<UserInput>({
    productInfo: '',
    targetAudience: [],
    useCase: [],
    productImages: [],
    language: 'Hinglish'
  });
  
  const [result, setResult] = useState<GeneratedContent | null>(null);
  const [loadingState, setLoadingState] = useState<LoadingState>(LoadingState.IDLE);
  const [errorMsg, setErrorMsg] = useState<string>('');

  const performGeneration = async (dataInput: UserInput) => {
    setLoadingState(LoadingState.LOADING);
    setErrorMsg('');
    setResult(null);

    try {
      const data = await generateAffiliateContent(dataInput);
      setResult(data);
      setLoadingState(LoadingState.SUCCESS);
    } catch (err) {
      console.error(err);
      setErrorMsg("We encountered a glitch in the matrix. Please try again.");
      setLoadingState(LoadingState.ERROR);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.productInfo || input.targetAudience.length === 0 || input.useCase.length === 0) {
      setErrorMsg("Please complete all fields to unlock the best content.");
      return;
    }
    performGeneration(input);
  };

  const handleLanguageSwitch = (langId: string) => {
      if (langId === input.language) return;
      
      const newInput = { ...input, language: langId };
      setInput(newInput);
      
      // If we already have a result, regenerate immediately in new language
      if (result || loadingState === LoadingState.SUCCESS) {
          performGeneration(newInput);
      }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
        const files: File[] = Array.from(e.target.files);
        if (files.length + input.productImages.length > 5) {
            setErrorMsg("Max 5 images allowed.");
            return;
        }

        const newImages: string[] = [];
        
        for (const file of files) {
            const reader = new FileReader();
            const promise = new Promise<string>((resolve) => {
                reader.onload = (e) => {
                    const result = e.target?.result as string;
                    // Remove data URL prefix to get pure base64
                    const base64 = result.split(',')[1];
                    resolve(base64);
                };
            });
            reader.readAsDataURL(file);
            newImages.push(await promise);
        }

        setInput(prev => ({ ...prev, productImages: [...prev.productImages, ...newImages] }));
    }
  };

  const removeImage = (index: number) => {
    setInput(prev => ({
        ...prev,
        productImages: prev.productImages.filter((_, i) => i !== index)
    }));
  };

  const handleGenerateVisual = async (index: number, visualCue: string, aspectRatio: string) => {
      if (!result) return;

      // Set loading state for this specific segment
      const updatedScript = [...result.script];
      updatedScript[index] = { ...updatedScript[index], isGeneratingImage: true };
      setResult({ ...result, script: updatedScript });

      try {
          // Use the first product image as reference if available
          const referenceImage = input.productImages.length > 0 ? input.productImages[0] : undefined;
          const base64Image = await generateImageForSegment(visualCue, referenceImage, aspectRatio);
          
          const finalScript = [...result.script];
          if (base64Image) {
             finalScript[index] = { 
                 ...finalScript[index], 
                 imageUrl: base64Image, 
                 isGeneratingImage: false 
             };
          } else {
             finalScript[index] = { ...finalScript[index], isGeneratingImage: false };
          }
          setResult({ ...result, script: finalScript });

      } catch (e) {
          console.error(e);
          const errorScript = [...result.script];
          errorScript[index] = { ...errorScript[index], isGeneratingImage: false };
          setResult({ ...result, script: errorScript });
      }
  };

  const getGenerateButtonText = () => {
    if (loadingState === LoadingState.LOADING) {
       switch (input.language) {
           case 'Hindi': return 'जनरेट हो रहा है...';
           case 'Hinglish': return 'Generating Chal Raha Hai...';
           default: return 'Generative AI Processing...';
       }
    }
    switch (input.language) {
        case 'Hindi': return 'वायरल स्क्रिप्ट जनरेट करें';
        case 'Hinglish': return 'Viral Script Generate Karein';
        default: return 'Generate Viral Script';
    }
  };

  return (
    <div className="min-h-screen pb-20 selection:bg-cyan-500/30 selection:text-cyan-100">
      {/* Background ambient effects - Dark Mode Optimized */}
      <div className="fixed top-0 left-0 w-full h-full overflow-hidden -z-10 pointer-events-none">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-600/10 rounded-full blur-3xl mix-blend-screen animate-pulse"></div>
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl mix-blend-screen animate-pulse delay-1000"></div>
        <div className="absolute bottom-0 left-1/3 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl mix-blend-screen"></div>
      </div>

      {/* Glass Header */}
      <header className="sticky top-0 z-50 glass-nav shadow-sm">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-tr from-cyan-500 to-blue-600 p-2.5 rounded-xl text-white shadow-lg shadow-cyan-500/20">
              <LayoutDashboard size={22} fill="currentColor" className="opacity-90" />
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-slate-100 leading-none">ViralReels<span className="text-cyan-400">.ai</span></h1>
              <p className="text-[10px] text-slate-500 font-semibold tracking-wider uppercase mt-0.5">India Affiliate Tool</p>
            </div>
          </div>
          <div className="flex gap-3">
             <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold bg-slate-900/80 backdrop-blur-sm border border-slate-800 px-4 py-2 rounded-full text-slate-400 shadow-sm hover:border-slate-700 hover:text-slate-300 transition-colors">
                <Youtube size={16} className="text-red-500" /> Shorts
             </div>
             <div className="hidden sm:flex items-center gap-1.5 text-xs font-semibold bg-slate-900/80 backdrop-blur-sm border border-slate-800 px-4 py-2 rounded-full text-slate-400 shadow-sm hover:border-slate-700 hover:text-slate-300 transition-colors">
                <Instagram size={16} className="text-pink-500" /> Reels
             </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        
        {/* Hero Section */}
        <div className="text-center mb-14 max-w-3xl mx-auto space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/20 text-cyan-400 text-xs font-bold uppercase tracking-wider mb-2 shadow-[0_0_10px_rgba(6,182,212,0.15)]">
            <Sparkles size={12} /> New: AI Model 2.5 Flash
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-slate-50 tracking-tight">
            Generate <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Viral Scripts</span> <br />in Milliseconds
          </h2>
          <p className="text-slate-400 text-lg md:text-xl font-light max-w-2xl mx-auto leading-relaxed">
            Transform product links into high-retention content tailored for the Indian market.
          </p>
        </div>

        {/* Input Card */}
        <div className="bg-slate-900/40 rounded-[2rem] shadow-[0_20px_50px_rgba(0,0,0,0.3)] border border-slate-800 p-1 md:p-2 max-w-5xl mx-auto mb-16 relative z-10 backdrop-blur-md">
           <div className="bg-slate-900/60 rounded-[1.8rem] p-6 md:p-10 border border-slate-800/50">
            <form onSubmit={handleGenerate} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                
                <div className="col-span-1 md:col-span-2">
                    <label className="block text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
                    <ShoppingBag size={18} className="text-cyan-400" />
                    Product Name or URL
                    </label>
                    <input
                    type="text"
                    className="w-full px-5 py-4 rounded-2xl bg-slate-950 border border-slate-800 focus:border-cyan-500/50 focus:ring-4 focus:ring-cyan-500/10 transition-all outline-none text-slate-200 placeholder:text-slate-600 text-base shadow-sm hover:border-slate-700"
                    placeholder="e.g. Boat Rockerz 450 or https://amzn.to/..."
                    value={input.productInfo}
                    onChange={(e) => setInput({ ...input, productInfo: e.target.value })}
                    />
                </div>

                {/* Target Audience Multi-Select */}
                <MultiSelectInput 
                    label="Target Audience"
                    icon={Target}
                    value={input.targetAudience}
                    onChange={(val) => setInput({...input, targetAudience: val})}
                    suggestions={SUGGESTED_AUDIENCES}
                    placeholder="e.g. Students, Moms, Gamers (Type & Enter)"
                    colorTheme="indigo"
                />

                {/* Use Case Multi-Select */}
                <MultiSelectInput 
                    label="Use Case / Angle"
                    icon={Zap}
                    value={input.useCase}
                    onChange={(val) => setInput({...input, useCase: val})}
                    suggestions={SUGGESTED_USE_CASES}
                    placeholder="e.g. Budget Gift, Travel Hack (Type & Enter)"
                    colorTheme="amber"
                />

                {/* Language Selection */}
                <div className="col-span-1 md:col-span-2">
                    <label className="block text-sm font-bold text-slate-300 mb-3 flex items-center gap-2">
                        <Globe size={18} className="text-emerald-400" />
                        Select Language
                    </label>
                    <div className="flex flex-wrap gap-3">
                        {LANGUAGES.map((lang) => (
                            <button
                                key={lang.id}
                                type="button"
                                onClick={() => setInput({ ...input, language: lang.id })}
                                className={`
                                    flex items-center gap-3 px-4 py-3 rounded-xl border transition-all flex-1 md:flex-none justify-center md:justify-start
                                    ${input.language === lang.id 
                                        ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 shadow-[0_0_15px_rgba(16,185,129,0.15)]' 
                                        : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800 hover:border-slate-700'}
                                `}
                            >
                                <div className={`w-4 h-4 rounded-full border flex items-center justify-center ${input.language === lang.id ? 'border-emerald-400' : 'border-slate-600'}`}>
                                    {input.language === lang.id && <div className="w-2 h-2 bg-emerald-400 rounded-full" />}
                                </div>
                                <div className="text-left">
                                    <div className="text-sm font-bold leading-none">{lang.label}</div>
                                    <div className="text-[10px] opacity-60 mt-0.5 font-medium uppercase tracking-wider">{lang.sub}</div>
                                </div>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Image Upload Section */}
                <div className="col-span-1 md:col-span-2">
                    <label className="block text-sm font-bold text-slate-300 mb-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                            <ImagePlus size={18} className="text-pink-500" />
                            Product Visuals (Optional)
                        </div>
                        <span className="text-xs font-normal text-slate-500">Max 5 images</span>
                    </label>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
                        {/* Upload Button */}
                        <label className={`flex flex-col items-center justify-center h-32 rounded-2xl border-2 border-dashed border-slate-800 bg-slate-950/50 hover:border-cyan-500/50 hover:bg-cyan-900/10 transition-all cursor-pointer ${input.productImages.length >= 5 ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''}`}>
                            <div className="p-3 bg-slate-900 rounded-full mb-2 border border-slate-800">
                                <Upload size={20} className="text-slate-400" />
                            </div>
                            <span className="text-xs font-semibold text-slate-500">Add Images</span>
                            <input 
                                type="file" 
                                multiple 
                                accept="image/*" 
                                className="hidden"
                                onChange={handleImageUpload}
                                disabled={input.productImages.length >= 5}
                            />
                        </label>

                        {/* Preview Images */}
                        {input.productImages.map((img, idx) => (
                            <div key={idx} className="relative group h-32 rounded-2xl overflow-hidden border border-slate-800 shadow-sm bg-slate-900">
                                <img 
                                    src={`data:image/jpeg;base64,${img}`} 
                                    alt="Upload preview" 
                                    className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
                                />
                                <button
                                    type="button"
                                    onClick={() => removeImage(idx)}
                                    className="absolute top-1.5 right-1.5 p-1.5 bg-black/60 hover:bg-red-500 text-white rounded-full backdrop-blur-sm transition-colors opacity-0 group-hover:opacity-100 border border-white/10"
                                >
                                    <X size={12} />
                                </button>
                            </div>
                        ))}
                    </div>
                </div>

                </div>

                {errorMsg && (
                <div className="bg-red-500/10 border border-red-500/20 text-red-400 px-4 py-3 rounded-xl flex items-center gap-3 text-sm font-medium animate-shake">
                    <AlertCircle size={18} />
                    {errorMsg}
                </div>
                )}

                <button
                type="submit"
                disabled={loadingState === LoadingState.LOADING}
                className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-5 rounded-2xl shadow-lg shadow-cyan-500/20 transform transition-all hover:-translate-y-1 active:scale-[0.99] disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-3 text-lg tracking-wide border border-white/10"
                >
                {loadingState === LoadingState.LOADING ? (
                    <>
                    <Loader2 className="animate-spin" /> {getGenerateButtonText()}
                    </>
                ) : (
                    <>
                    <Sparkles fill="currentColor" className="animate-pulse" /> {getGenerateButtonText()}
                    </>
                )}
                </button>
            </form>
           </div>
        </div>

        {/* Results Area */}
        {result && (
          <div className="animate-fade-in space-y-8">
            
            {/* 1. Hooks & Thumbnail - Top Priority */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <ResultSection 
                title="Viral Hooks (Start Here)" 
                icon={Zap} 
                content={result.hooks}
                accentColor="amber"
              />
              <ResultSection 
                title="Thumbnail Text Options" 
                icon={ImageIcon} 
                content={result.thumbnail_texts}
                accentColor="rose"
              />
            </div>

            {/* 2. Main Script Card */}
            <div className="bg-slate-900/80 rounded-[2.5rem] shadow-[0_20px_40px_rgba(0,0,0,0.3)] border border-slate-800 overflow-hidden relative">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600"></div>
              <div className="p-8 md:p-10">
                <div className="flex flex-wrap items-center gap-4 mb-10">
                    <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
                         <Youtube size={28} />
                    </div>
                    <div>
                        <h3 className="text-2xl md:text-3xl font-bold text-slate-100 tracking-tight">Generated Script</h3>
                        <p className="text-slate-500 font-medium text-sm">Optimized for high retention (20-25s)</p>
                    </div>
                    
                    {/* Quick Language Switcher */}
                    <div className="ml-auto flex items-center bg-slate-950 rounded-lg p-1 border border-slate-800">
                        {LANGUAGES.map(lang => (
                            <button
                                key={lang.id}
                                onClick={() => handleLanguageSwitch(lang.id)}
                                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all ${
                                    input.language === lang.id 
                                    ? 'bg-slate-800 text-cyan-400 shadow-sm' 
                                    : 'text-slate-500 hover:text-slate-300 hover:bg-slate-900'
                                }`}
                            >
                                {lang.label}
                            </button>
                        ))}
                    </div>
                </div>

                <ScriptTimeline 
                    script={result.script} 
                    onGenerateVisual={handleGenerateVisual}
                />
                
                {/* CTAs embedded nicely */}
                <div className="mt-10 pt-8 border-t border-dashed border-slate-800">
                   <div className="flex items-center gap-2 mb-4 text-sm font-bold text-slate-500 uppercase tracking-widest">
                      <Target size={14} /> Call To Actions
                   </div>
                   <div className="flex flex-wrap gap-3">
                      {result.ctas.map((cta, idx) => (
                          <button key={idx} 
                            onClick={() => navigator.clipboard.writeText(cta)}
                            className="group px-5 py-2.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 text-sm font-semibold rounded-xl border border-emerald-500/20 transition-colors flex items-center gap-2"
                          >
                              {cta}
                              <span className="opacity-0 group-hover:opacity-100 transition-opacity text-xs text-emerald-300">
                                <MessageCircle size={12} />
                              </span>
                          </button>
                      ))}
                   </div>
                </div>
              </div>
            </div>

            {/* 3. SEO & Metadata Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              {/* Caption & Tags */}
              <div className="lg:col-span-1 flex flex-col gap-8">
                 <ResultSection 
                    title="SEO Caption" 
                    icon={MessageCircle} 
                    content={result.caption}
                    accentColor="blue"
                 />
                 <ResultSection 
                    title="#India Hashtags" 
                    icon={Hash} 
                    content={result.hashtags}
                    accentColor="blue"
                 />
              </div>

              {/* Benefits */}
              <div className="lg:col-span-1">
                 <ResultSection 
                    title="Key Benefits" 
                    icon={CheckCircle2} 
                    content={result.benefits}
                    accentColor="emerald"
                 />
              </div>

              {/* Pain Points */}
              <div className="lg:col-span-1">
                 <ResultSection 
                    title="Pain Points Solved" 
                    icon={AlertTriangle} 
                    content={result.pain_points}
                    accentColor="orange"
                 />
              </div>
            </div>

            <div className="text-center pt-12 pb-8 opacity-60">
               <p className="text-slate-600 text-sm font-medium">Powered by Gemini 2.5 Flash • ViralReels AI</p>
            </div>

          </div>
        )}
      </main>
    </div>
  );
};

export default App;
