import React, { useState } from 'react';
import { ScriptSegment } from '../types';
import { Copy, Clock, Video, Mic, Loader2, Sparkles, Download, Maximize2, X, RotateCw, Square, Smartphone, Monitor } from 'lucide-react';

interface Props {
  script: ScriptSegment[];
  onGenerateVisual: (index: number, visualCue: string, aspectRatio: string) => void;
}

const ASPECT_RATIOS = [
    { label: '1:1', value: '1:1', icon: Square },
    { label: '9:16', value: '9:16', icon: Smartphone },
    { label: '16:9', value: '16:9', icon: Monitor },
];

const TimelineItem: React.FC<{
    item: ScriptSegment;
    index: number;
    onGenerate: (aspectRatio: string) => void;
    onOpenLightbox: (img: string) => void;
}> = ({ item, index, onGenerate, onOpenLightbox }) => {
    const [selectedRatio, setSelectedRatio] = useState('1:1');
    
    const copyToClipboard = (text: string) => {
        navigator.clipboard.writeText(text);
    };

    const handleDownload = () => {
        if (!item.imageUrl) return;
        const link = document.createElement('a');
        link.href = `data:image/jpeg;base64,${item.imageUrl}`;
        link.download = `viralreels-visual-${index + 1}.jpg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="relative md:pl-16 group">
            {/* Timeline Dot */}
            <div className="hidden md:flex absolute left-2 top-5 w-9 h-9 bg-slate-900 border-2 border-cyan-500/50 rounded-full items-center justify-center text-cyan-400 text-sm font-bold shadow-[0_0_15px_rgba(6,182,212,0.2)] z-10 group-hover:scale-110 transition-transform duration-300 group-hover:border-cyan-400">
                {index + 1}
            </div>
            
            <div className="bg-slate-900 rounded-2xl border border-slate-800 shadow-[0_4px_20px_rgba(0,0,0,0.2)] p-6 transition-all hover:border-slate-700 hover:shadow-[0_10px_25px_rgba(0,0,0,0.3)] hover:-translate-y-0.5">
                
                {/* Header */}
                <div className="flex flex-wrap justify-between items-center mb-5 gap-2">
                    <div className="flex items-center gap-3">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest border ${
                            item.segment.toLowerCase().includes('hook') ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' :
                            item.segment.toLowerCase().includes('cta') ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                            'bg-indigo-500/10 text-indigo-400 border-indigo-500/20'
                        }`}>
                            {item.segment}
                        </span>
                        <div className="flex items-center text-xs font-medium text-slate-400 bg-slate-950 border border-slate-800 px-2 py-1 rounded-md">
                            <Clock size={12} className="mr-1.5" />
                            {item.time}
                        </div>
                    </div>
                    <button 
                        onClick={() => copyToClipboard(item.text)}
                        className="text-slate-500 hover:text-cyan-400 transition-colors p-1.5 hover:bg-cyan-500/10 rounded-lg"
                        title="Copy Script Line"
                    >
                        <Copy size={16} />
                    </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {/* Audio Section */}
                    <div className="space-y-3">
                        <div className="flex items-center text-[11px] text-slate-500 font-bold uppercase tracking-wider">
                            <Mic size={12} className="mr-1.5 text-cyan-500" /> Audio (Hinglish)
                        </div>
                        <p className="text-slate-200 font-medium text-lg leading-relaxed selection:bg-cyan-500/30 selection:text-cyan-100">
                            "{item.text}"
                        </p>
                    </div>

                    {/* Visual Section */}
                    <div className="space-y-3">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                            <div className="flex items-center text-[11px] text-slate-500 font-bold uppercase tracking-wider">
                                <Video size={12} className="mr-1.5 text-indigo-500" /> Visual Cue
                            </div>
                            
                            {!item.isGeneratingImage && (
                                <div className="flex items-center gap-1">
                                    {/* Ratio Selectors */}
                                    <div className="flex bg-slate-950 rounded-lg p-0.5 mr-1 border border-slate-800">
                                        {ASPECT_RATIOS.map((ratio) => {
                                            const Icon = ratio.icon;
                                            return (
                                                <button
                                                    key={ratio.value}
                                                    onClick={() => setSelectedRatio(ratio.value)}
                                                    className={`p-1.5 rounded-md transition-all ${selectedRatio === ratio.value ? 'bg-slate-800 text-cyan-400 shadow-sm' : 'text-slate-500 hover:text-slate-300'}`}
                                                    title={ratio.label}
                                                >
                                                    <Icon size={12} />
                                                </button>
                                            );
                                        })}
                                    </div>

                                    <button 
                                        onClick={() => onGenerate(selectedRatio)}
                                        className="flex items-center gap-1.5 text-[10px] font-bold text-white bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 px-3 py-1.5 rounded-lg shadow-sm shadow-cyan-900/20 transition-all active:scale-95 border border-cyan-500/20"
                                    >
                                        <Sparkles size={10} fill="currentColor" /> 
                                        {item.imageUrl ? 'Regenerate' : 'Generate 4K'}
                                    </button>
                                </div>
                            )}
                        </div>
                        
                        <div className="bg-slate-950/50 rounded-xl p-4 border border-slate-800 flex flex-col gap-3">
                            <p className="text-slate-400 text-sm italic leading-relaxed">
                                {item.visual_cue}
                            </p>

                            {/* Image Generation State */}
                            {item.isGeneratingImage && (
                                <div className="w-full aspect-video bg-slate-900 rounded-lg flex flex-col items-center justify-center text-slate-400 text-xs animate-pulse border border-slate-800">
                                    <Loader2 size={24} className="animate-spin mb-3 text-cyan-500" />
                                    Generating 4K Visual ({selectedRatio})...
                                </div>
                            )}

                            {item.imageUrl && !item.isGeneratingImage && (
                                <div className="relative group w-full rounded-lg overflow-hidden border border-slate-700 shadow-lg bg-slate-900">
                                    <img 
                                        src={`data:image/jpeg;base64,${item.imageUrl}`} 
                                        alt="Generated visual" 
                                        className="w-full h-auto object-cover cursor-pointer opacity-90 group-hover:opacity-100 transition-opacity"
                                        onClick={() => onOpenLightbox(item.imageUrl!)}
                                    />
                                    
                                    {/* Image Overlays */}
                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                        <button 
                                            onClick={() => onOpenLightbox(item.imageUrl!)}
                                            className="p-2 bg-white/10 backdrop-blur-md rounded-full text-white border border-white/20 hover:bg-white/20 transition-colors"
                                            title="View Full Size"
                                        >
                                            <Maximize2 size={16} />
                                        </button>
                                        <button 
                                            onClick={handleDownload}
                                            className="p-2 bg-white/10 backdrop-blur-md rounded-full text-white border border-white/20 hover:bg-white/20 transition-colors"
                                            title="Download Image"
                                        >
                                            <Download size={16} />
                                        </button>
                                        <button 
                                            onClick={() => onGenerate(selectedRatio)}
                                            className="p-2 bg-white/10 backdrop-blur-md rounded-full text-white border border-white/20 hover:bg-white/20 transition-colors"
                                            title="Regenerate"
                                        >
                                            <RotateCw size={16} />
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const ScriptTimeline: React.FC<Props> = ({ script, onGenerateVisual }) => {
    const [lightboxImage, setLightboxImage] = useState<string | null>(null);

    return (
        <div className="space-y-8 relative pl-2">
            {/* Timeline Vertical Line */}
            <div className="absolute left-[1.65rem] top-4 bottom-4 w-px bg-slate-800 hidden md:block"></div>
            
            {script.map((item, idx) => (
                <TimelineItem 
                    key={idx} 
                    item={item} 
                    index={idx} 
                    onGenerate={(aspectRatio) => onGenerateVisual(idx, item.visual_cue, aspectRatio)}
                    onOpenLightbox={setLightboxImage}
                />
            ))}

            {/* Lightbox Modal */}
            {lightboxImage && (
                <div className="fixed inset-0 z-[100] bg-slate-950/95 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in" onClick={() => setLightboxImage(null)}>
                    <button 
                        className="absolute top-5 right-5 text-slate-400 hover:text-white transition-colors"
                        onClick={() => setLightboxImage(null)}
                    >
                        <X size={32} />
                    </button>
                    <div className="relative max-w-5xl w-full max-h-[90vh] flex items-center justify-center" onClick={(e) => e.stopPropagation()}>
                        <img 
                            src={`data:image/jpeg;base64,${lightboxImage}`} 
                            alt="Full size preview" 
                            className="max-w-full max-h-[85vh] object-contain rounded-lg shadow-2xl border border-slate-800"
                        />
                        <div className="absolute bottom-[-4rem] left-0 right-0 flex justify-center">
                             <button 
                                onClick={(e) => {
                                    e.stopPropagation();
                                    const link = document.createElement('a');
                                    link.href = `data:image/jpeg;base64,${lightboxImage}`;
                                    link.download = `viralreels-visual-full.jpg`;
                                    link.click();
                                }}
                                className="flex items-center gap-2 bg-white text-slate-900 px-6 py-3 rounded-full font-bold text-sm hover:bg-slate-200 transition-colors shadow-lg shadow-white/10"
                             >
                                 <Download size={18} /> Download 4K
                             </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ScriptTimeline;