import React from 'react';
import { Copy, LucideIcon } from 'lucide-react';

interface Props {
  title: string;
  icon: LucideIcon;
  content?: string | string[];
  accentColor?: string; // e.g., "cyan", "blue", "indigo"
}

const ResultSection: React.FC<Props> = ({ 
  title, 
  icon: Icon, 
  content, 
  accentColor = "cyan" 
}) => {
  
  if (!content || (Array.isArray(content) && content.length === 0)) return null;

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const handleCopyAll = () => {
    if (Array.isArray(content)) {
      copyToClipboard(content.join('\n'));
    } else {
      copyToClipboard(content);
    }
  };

  // Dynamic class generation for dark theme accent colors
  // Using tailwind arbitrary values for dynamic colors or mapping would be safer, 
  // but assuming standard tailwind config, we construct classes.
  // Adjusted for dark mode: lighter text, darker bg with opacity
  const bgLight = `bg-${accentColor}-500/10`;
  const textDark = `text-${accentColor}-400`;
  const hoverText = `hover:text-${accentColor}-300`;
  const borderHover = `hover:border-${accentColor}-500/30`;

  return (
    <div className="bg-slate-900/80 backdrop-blur-sm rounded-3xl p-6 shadow-lg shadow-black/20 border border-slate-800 h-full flex flex-col transition-all hover:border-slate-700 hover:shadow-black/30">
      <div className="flex justify-between items-center mb-5 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl ${bgLight} ${textDark} ring-1 ring-inset ring-${accentColor}-500/20`}>
             <Icon size={22} />
          </div>
          <h3 className="font-bold text-lg text-slate-100 tracking-tight">{title}</h3>
        </div>
        <button 
            onClick={handleCopyAll}
            className={`text-xs flex items-center gap-1.5 text-slate-400 ${hoverText} font-semibold transition-colors bg-slate-800 px-3 py-1.5 rounded-lg border border-slate-700 hover:bg-slate-750 ${borderHover}`}
        >
            <Copy size={13} /> Copy All
        </button>
      </div>
      
      <div className="flex-grow">
        {Array.isArray(content) ? (
          <ul className="space-y-3">
            {content.map((item, idx) => (
              <li key={idx} className="group flex items-start justify-between p-3 rounded-xl hover:bg-slate-800/80 transition-colors text-sm text-slate-300 font-medium border border-transparent hover:border-slate-700/50">
                <span className="leading-relaxed">{item}</span>
                <button 
                  onClick={() => copyToClipboard(item)}
                  className={`opacity-0 group-hover:opacity-100 text-slate-500 ${hoverText} transition-all ml-3 shrink-0 p-1`}
                >
                  <Copy size={14} />
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="relative group h-full">
            <div className="whitespace-pre-wrap text-sm text-slate-300 leading-relaxed bg-slate-950/50 p-4 rounded-2xl border border-slate-800 font-medium h-full">
                {content}
            </div>
            <button 
                onClick={() => copyToClipboard(content)}
                className={`absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-2 bg-slate-800 rounded-lg shadow-sm border border-slate-700 text-slate-400 ${hoverText} transition-all`}
            >
                <Copy size={14} />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResultSection;